import { Component, OnInit } from '@angular/core';
import * as albumData from '../data/SearchResultsAlbums.json';
import * as artistData from '../data/SearchResultsArtist.json';


@Component({
  selector: 'app-artist',
  templateUrl: './artist.component.html',
  styleUrls: ['./artist.component.css']
})
export class ArtistComponent implements OnInit {
  albums : Array<any>=[] ;
  artist = (artistData as any).default;
  constructor() { 
    
  }

  ngOnInit(): void {
    this.artist = (artistData as any).default;
    this.albums = (albumData as any).default.albums.items;
    
  }

}
